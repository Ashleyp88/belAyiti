This is a starter plugin for developers which can significantly reduce time spent on development of plugins/templates and give you valuable insight on how to structure your plugin/template.


Rquirements:
	- jQuery 1.7+ JS library: 	http://jquery.com/
	- mightySlider plugin:  	http://mightyslider.com/

Install:
	1. Copy "starter plugin" folder to "extend" folder in mightySlider folder.
	2. Open "starter.html" file.

Release changes:
	- v1.0.0 [2014/04/22]
	Initial release of mightySlider starter plugin.